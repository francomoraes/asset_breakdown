import { AppDataSource } from "config/data-source";
import { Request, Response } from "express";
import { AssetClass } from "models/AssetClass";
import { AssetType } from "models/AssetType";
import { userIdParamsSchema } from "schemas/asset.schema";
import {
  assetClassCreateSchema,
  assetClassIdParamSchema,
} from "schemas/assetClass.schema";
import { handleZodError } from "utils/handleZodError";

export const createAssetClass = async (
  req: Request,
  res: Response,
): Promise<void> => {
  const paramsCheck = userIdParamsSchema.safeParse(req.params);
  const bodyCheck = assetClassCreateSchema.safeParse(req.body);

  if (!paramsCheck.success)
    return handleZodError(res, paramsCheck.error, "Invalid user ID");

  if (!bodyCheck.success)
    return handleZodError(res, bodyCheck.error, "Invalid asset class data");

  const { userId } = paramsCheck.data;
  const { name } = bodyCheck.data;

  try {
    const repo = AppDataSource.getRepository(AssetClass);

    const existingAssetClass = await repo.findOne({ where: { name, userId } });

    if (existingAssetClass) {
      res.status(409).json({ error: "Asset class already exists" });
      return;
    }

    const assetClass = repo.create({
      name,
      userId,
    });

    await repo.save(assetClass);

    res.status(201).json({
      message: "Asset class created successfully",
      assetClass,
    });
  } catch (error) {
    console.error("Error creating asset class:", error);
    res.status(500).json({ error: "Internal server error" });
  }
};

export const getAssetClasses = async (
  req: Request,
  res: Response,
): Promise<void> => {
  const paramsCheck = userIdParamsSchema.safeParse(req.params);

  if (!paramsCheck.success) {
    return handleZodError(res, paramsCheck.error, "Invalid user ID");
  }

  const { userId } = paramsCheck.data;

  try {
    const repo = AppDataSource.getRepository(AssetClass);
    const assetClasses = await repo.find({
      where: { userId },
      order: { name: "ASC" },
    });

    res.json(assetClasses);
  } catch (error) {
    console.error("Error fetching asset classes:", error);
    res.status(500).json({ error: "Internal server error" });
  }
};

export const updateAssetClass = async (
  req: Request,
  res: Response,
): Promise<void> => {
  const parsedParams = assetClassIdParamSchema
    .merge(userIdParamsSchema)
    .safeParse(req.params);
  const parsedBody = assetClassCreateSchema.safeParse(req.body);

  if (!parsedParams.success || !parsedBody.success) {
    res.status(400).json({
      error: "Invalid parameters or body",
    });
    return;
  }

  const { id, userId } = parsedParams.data;
  const { name } = parsedBody.data;

  try {
    const repo = AppDataSource.getRepository(AssetClass);
    const assetClass = await repo.findOne({
      where: { id: Number(id), userId },
    });

    if (!assetClass) {
      res.status(404).json({ error: "Asset class not found" });
      return;
    }

    if (name !== undefined) assetClass.name = name;
    await repo.save(assetClass);

    res.json({ message: "Asset class updated successfully", assetClass });
  } catch (error) {
    console.error("Error updating asset class:", error);
    res.status(500).json({ error: "Internal server error" });
  }
};

export const deleteAssetClass = async (
  req: Request,
  res: Response,
): Promise<void> => {
  const parsedParams = assetClassIdParamSchema
    .merge(userIdParamsSchema)
    .safeParse(req.params);

  if (!parsedParams.success) {
    res.status(400).json({ error: "Invalid parameters" });
    return;
  }

  const { id, userId } = parsedParams.data;

  try {
    const repo = AppDataSource.getRepository(AssetClass);
    const assetClass = await repo.findOne({
      where: { id: Number(id), userId },
    });

    if (!assetClass) {
      res.status(404).json({ error: "Asset class not found" });
      return;
    }

    const assetTypesRepo = AppDataSource.getRepository(AssetType);
    const assetTypes = await assetTypesRepo.find({
      where: { assetClass, userId },
    });

    if (assetTypes.length > 0) {
      res.status(400).json({
        error: "Cannot delete asset class with associated asset types",
      });
      return;
    }

    await repo.delete({
      id: Number(id),
      userId,
    });

    res.json({
      message: `Asset class ${assetClass.name} deleted successfully`,
    });
  } catch (error) {
    console.error("Error deleting asset class:", error);
    res.status(500).json({ error: "Internal server error" });
  }
};
