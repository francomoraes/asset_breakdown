import { Router } from "express";

const router = Router();

router.get("/asset-class/:userId", () => {});
router.post("/asset-class/:userId", () => {});
router.patch("/asset-class/:userId/:id", () => {});
router.delete("/asset-class/:userId/:id", () => {});

export default router;
