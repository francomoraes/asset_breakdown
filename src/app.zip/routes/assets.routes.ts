import express from "express";
import { createAsset, getAssets } from "../controllers/assets.controller";

const router = express.Router();
router.get("/assets", getAssets);
router.post("/assets", createAsset);

export default router;
