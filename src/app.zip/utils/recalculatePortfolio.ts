import { AppDataSource } from "../config/data-source.js";
import { Asset } from "../models/Asset.js";

export async function recalculatePortfolio() {
  const assetRepository = AppDataSource.getRepository(Asset);

  const allAssets = await assetRepository.find();

  const totalCurrentValue = allAssets.reduce(
    (sum, a) => sum + a.currentValueCents,
    0,
  );

  for (const a of allAssets) {
    a.portfolioPercentage =
      totalCurrentValue > 0
        ? Number(((a.currentValueCents / totalCurrentValue) * 100).toFixed(2))
        : 0;
  }

  await assetRepository.save(allAssets);
}
