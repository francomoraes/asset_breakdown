import { Request, Response } from "express";
import { AppDataSource } from "../config/data-source";
import { Asset } from "../models/Asset";
import yahooFinance from "yahoo-finance2";
import { recalculatePortfolio } from "../utils/recalculatePortfolio";

export const getAssets = async (req: Request, res: Response) => {
  try {
    const assetRepository = AppDataSource.getRepository(Asset);
    const assets = await assetRepository.find();
    res.status(200).json(assets);
  } catch (error) {
    console.error("Erro ao buscar ativos:", error);
    res.status(500).json({ error: "Erro ao buscar ativos" });
  }
};

export const createAsset = async (req: Request, res: Response) => {
  try {
    const { type, ticker, quantity, averagePriceCents, institution, currency } =
      req.body;

    const investedValueCents = quantity * averagePriceCents;
    let currentPriceCents = 0;

    try {
      const quote: any = await yahooFinance.quote(ticker);
      const marketPrice = Array.isArray(quote)
        ? quote[0].regularMarketPrice
        : quote?.regularMarketPrice;

      currentPriceCents = Math.round(marketPrice * 100);
    } catch (error) {
      console.error(`Erro ao buscar dados para o ticker ${ticker}:`, error);
      res.status(500).json({ error: "Erro ao buscar dados do ativo" });
    }

    const currentValueCents = quantity * currentPriceCents;
    const resultCents = currentValueCents - investedValueCents;

    const asset = AppDataSource.getRepository(Asset).create({
      type,
      ticker,
      quantity,
      averagePriceCents,
      currentPriceCents,
      investedValueCents,
      currentValueCents,
      resultCents,
      returnPercentage: Number(
        ((resultCents / investedValueCents) * 100).toFixed(2),
      ),
      portfolioPercentage: 0,
      institution,
      currency,
    });

    await AppDataSource.getRepository(Asset).save(asset);

    await recalculatePortfolio();

    res.status(201).json(asset);
  } catch (error) {
    console.error("Erro ao criar ativo:", error);
    res.status(500).json({ error: "Erro ao criar ativo" });
  }
};
